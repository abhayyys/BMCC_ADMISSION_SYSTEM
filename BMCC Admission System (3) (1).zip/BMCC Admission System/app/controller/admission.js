mainApp.controller("admissionCtrl", function ($scope, $http, $log) {
    $scope.admission = [];

    var successCallback = function (response) {
        $scope.admission = response.data; // Update to $scope.admissiondata
        $log.info(response.data);
    }

    var errorCallback = function (reason) {
        $errormessage = reason.data;
        $log.info(reason);
    }

    $http({
        method: "GET",
        url: "app/data/admission.json"
    }).then(successCallback, errorCallback);

});
