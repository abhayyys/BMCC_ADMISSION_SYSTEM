mainApp.controller("facultyCtrl", function ($scope, $log, $http) {
    $scope.faculties = []; // Use faculties as the variable name

    $scope.selectedFilter = ''; // Default filter criterion (empty for "All")
    $scope.searchText = ''; // Initial search text

    var successCallback = function (response) {
        $scope.faculties = response.data;
        $log.info(response.data);
    }

    var errorCallback = function (reason) {
        $errormessage = reason.data;
        $log.info(reason);
    }

    // Fetch faculties from JSON file
    $http({
        method: "GET",
        url: "app/data/faculty.json"
    }).then(successCallback, errorCallback);

    $scope.recordsPerPage = 8; // No. of display faculties data per page 
    $scope.currentPage = 0;  //index page

    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };

    $scope.prevPageDisabled = function () {
        return $scope.currentPage === 0 ? "disabled" : "";
    };

    $scope.pageCount = function () {
        // Calculate the page count based on the length of faculties
        return Math.min(5, Math.ceil($scope.faculties.length / $scope.recordsPerPage) - 1); // Display a maximum of 5 pages
    };

    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pageCount()) {
            $scope.currentPage++;
        }
    };

    $scope.nextPageDisabled = function () {
        return $scope.currentPage === $scope.pageCount() ? "disabled" : "";
    };
});
