var mainApp = angular.module("mainApp", ['ngRoute']);

mainApp.config(function($routeProvider){
    $routeProvider.when("/",{
        templateUrl:'app/views/home.html',
        controller:'homeCtrl'
    })
    .when("/admission",{
        templateUrl:'app/views/admission.html',
        controller:'admissionCtrl'
    })
    .when("/faculty",{
        templateUrl:'app/views/faculty.html',
        controller:'facultyCtrl'
    })
    .when("/alumni",{
        templateUrl:'app/views/alumni.html',
        controller:'alumniCtrl'
    })
    .when("/event",{
        templateUrl:'app/views/event.html',
        controller:'eventCtrl'
    })
    .when("/studentRegistration",{
        templateUrl:'app/views/studentRegistration.html',
        controller:'studentCtrl'
    })
    .when("/studentRecord",{
        templateUrl:'app/views/studentRecord.html',
        controller:'studentRecordCtrl'
    })
    .when("/contactus",{
        templateUrl:'app/views/contact.html',
        controller:'contactCtrl'
    })
    .otherwise({redirectTo:'/'})

    
});