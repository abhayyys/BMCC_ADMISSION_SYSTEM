// Define the properCaseService AngularJS service
mainApp.service('properCaseService', function () {
    this.processString = function (inputString) {
        var outputString = "";
        inputString = inputString.toLowerCase().split(' ');
        for (let i = 0; i < inputString.length; i++) {
            inputString[i] = inputString[i].charAt(0).toUpperCase() + inputString[i].slice(1);
        }
        outputString = inputString.join(' ');
        return outputString;
    };
});
