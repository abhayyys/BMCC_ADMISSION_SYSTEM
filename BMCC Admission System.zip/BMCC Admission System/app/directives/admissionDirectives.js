// Custom validation for name
mainApp.directive('checkName', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ctrl) {
            ctrl.$validators.checkName = function (viewValue) {
                var validCharacters = /^[a-zA-Z\s]*$/; // Only allow letters and spaces
                return validCharacters.test(viewValue);
            };
        }
    };
});

// Custom validation for contact number
mainApp.directive('checkContactNumber', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ctrl) {
            ctrl.$validators.checkContactNumber = function (viewValue) {
                var validFormat = /^\d{10}$/; // Assumes a 10-digit format
                return validFormat.test(viewValue);
            };
        }
    };
});

// Custom validation for email
mainApp.directive('checkEmail', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ctrl) {
            ctrl.$validators.checkEmail = function (viewValue) {
                var validEmailFormat = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                return validEmailFormat.test(viewValue);
            };
        }
    };
});

// Custom validation for Date of Birth
mainApp.directive('minimumAge', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, ctrl) {
            ctrl.$validators.minimumAge = function (modelValue) {
                if (modelValue) {
                    var birthDate = new Date(modelValue);
                    var currentDate = new Date();
                    var age = currentDate.getFullYear() - birthDate.getFullYear();
                    var monthDiff = currentDate.getMonth() - birthDate.getMonth();

                    if (monthDiff < 0 || (monthDiff === 0 && currentDate.getDate() < birthDate.getDate())) {
                        age--;
                    }

                    // Check if age is between 16 and 25
                    return age >= 16 && age <= 25;
                }
                return false;
            };
        }
    };
});



//Custom Directive for heading
mainApp.directive("insertHeader", function () {
    return {
        template: "<h1>Events</h1>"
    };
});