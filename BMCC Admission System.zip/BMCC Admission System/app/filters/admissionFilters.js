// Used for faculty list
mainApp.filter('facultyoffset', function () {
    return function (input, start) {
        start = parseInt(start, 10);
        return input.slice(start, start + 8); // Display 8 faculties per page
    };
});

// Used for Students list
mainApp.filter('studentoffset', function () {
    return function (input, start) {
        start = parseInt(start, 10);
        return input.slice(start, start + 15); // Display 15 records per page
    };
});