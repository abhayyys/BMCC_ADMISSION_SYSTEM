var loginApp = angular.module('loginApp', []);

loginApp.controller('LoginController', function ($scope, $location, $window, $http , $log) {
    $scope.name = "Login Page";
    $scope.errorMessage = "";

    var successCallback = function (response) {
        $scope.users = response.data;
        $log.info(response.data);
    }

    var errorCallback = function (reason) {
        $scope.errormessage = reason.data;
        $log.info(reason);
    }

    // Fetch login credentials from JSON file
    $http({
        method: "GET",
        url: "data/login.json" // Adjust the URL to match your JSON file path
    }).then(successCallback, errorCallback);

    $scope.login = function () {
        var username = $scope.userName;
        var password = $scope.password;

        // Check if the username and password match a user in the JSON data
        var matchedUser = $scope.users.find(function (user) {
            return user.user === username && user.password === password;
        });

        if (matchedUser) {
            // Successful login, redirect to another page
            $scope.newPath = $location.protocol() + '://'
                + $location.host() + ':' + $location.port()
                + '/' + 'index.html';
            $window.location.href = $scope.newPath;
        } else {
            // Display an error message for an invalid login
            $scope.errorMessage = "Invalid username/password";
        }
    };
});
