mainApp.controller("eventCtrl", function ($scope, $http, $log) {
    $scope.Events = [];

    var successCallback = function (Response) {
        $scope.Events = Response.data;
        $log.info(Response.data);
    }

    var errorCallback = function (Reason) {
        $errormessage = Reason.data;
        $log.info(Reason);
    }

    $http({
        method: "GET",
        url: "app/data/event.json"
    }).then(successCallback, errorCallback);
});
