mainApp.controller("contactCtrl", function ($scope, $interval) {
    // Built-in Services
    $scope.currentTime = new Date().toLocaleTimeString();
    $interval(function () {
        $scope.currentTime = new Date().toLocaleTimeString();
    }, 1000);
     
    //flag for form & message
    $scope.showForm=false;
    
    $scope.name = '';
    $scope.contactNumber = '';
    $scope.email = '';
    $scope.message = '';
    $scope.submitted = false; // Initialize the submitted variable as false


    $scope.sendMessage = function () {

        // You can access form data from $scope.name, $scope.contactNumber, $scope.email, and $scope.message
        console.log("Name: " + $scope.name);
        console.log("Contact Number: " + $scope.contactNumber);
        console.log("Email: " + $scope.email);
        console.log("Message: " + $scope.message);

        $scope.submitted = true;
        $scope.showForm=true;

    };

});



