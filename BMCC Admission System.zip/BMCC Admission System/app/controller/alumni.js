mainApp.controller("alumniCtrl", function ($scope, $http,$log) {
    $scope.testimonials=[];

    var successCallback = function (response) {
        $scope.testimonials = response.data; // Update to $scope.alumnidata
        $log.info(response.data);
    }

    var errorCallback = function (reason) {
        $errormessage = reason.data;
        $log.info(reason);
    }

    $http({
        method: "GET",
        url: "app/data/alumni.json"
    }).then(successCallback, errorCallback);

});
