mainApp.controller("studentRecordCtrl", function ($scope, $http, $log) {
    $scope.students = [];
    $scope.searchText = ''; // Initial search text
    $scope.selectedFilter = ''; // Default filter criterion (empty for "All")

    var successCallback = function (response) {
        $scope.students = response.data; // Update to $scope.studentdata
        $log.info(response.data);
    }

    var errorCallback = function (reason) {
        $errormessage = reason.data;
        $log.info(reason);
    }

    $http({
        method: "GET",
        url: "app/data/studentData.json"
    }).then(successCallback, errorCallback);

    $scope.recordsPerPage = 15;
    $scope.currentPage = 0;

    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };

    $scope.prevPageDisabled = function () {
        return $scope.currentPage === 0 ? "disabled" : "";
    };

    $scope.pageCount = function () {
        // Calculate the page count based on the length of students
        return Math.min(5, Math.ceil($scope.students.length / $scope.recordsPerPage) - 1); // Display a maximum of 5 pages
    };

    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pageCount()) {
            $scope.currentPage++;
        }
    };

    $scope.nextPageDisabled = function () {
        return $scope.currentPage === $scope.pageCount() ? "disabled" : "";
    };


});