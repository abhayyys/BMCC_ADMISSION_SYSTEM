mainApp.controller("studentCtrl", function ($scope, properCaseService) {
    $scope.form = [];
    // Initialize a flag to control form and table visibility
    $scope.showDiv = false;
    $scope.submittedMessage = false;

     // Initialize student_name with an empty string
     $scope.student_name = '';

    // Initialize an array to store submitted data
    $scope.form = [
        {
            "student_name": "Ajay Deo",
            "mobile": "7658974587",
            "date_of_birth": "01-15-1998",
            "id_proof": "ABC165478",
            "selectedOperator": "Science",
            "gender": "Male",
            "marks_10th": "95",
            "marks_12th": "88",
            "entrance_marks": "75",
            "pincode":"411200",
            "address": "123 Link Road",
            "city": "Vile Parle",
            "state": "Maharashtra"
        },
        {
            "student_name": "Deepali More",
            "mobile": "9876543210",
            "date_of_birth": "05-20-1999",
            "id_proof": "GFD745687",
            "selectedOperator": "Commerce",
            "gender": "Female",
            "marks_10th": "92",
            "marks_12th": "90",
            "entrance_marks": "80",
            "pincode":"41100",
            "address": "456 Nashik Road",
            "city": "Nashik",
            "state": "Maharashtra"
        },
        {
            "student_name": "Varen Agarwal",
            "mobile": "6541478987",
            "date_of_birth": "11-10-2000",
            "id_proof": "ACF7458977",
            "selectedOperator": "Arts",
            "gender": "Male",
            "marks_10th": "88",
            "marks_12th": "86",
            "entrance_marks": "70",
            "pincode":"433900",
            "address": "789 Jalna Road",
            "city": "Jalna",
            "state": "Maharastra"
        },
        {
            "student_name": "Ketaki Sharma",
            "mobile": "1112223333",
            "date_of_birth": "03-05-1997",
            "id_proof": "VFD223333",
            "selectedOperator": "Science",
            "gender": "Female",
            "marks_10th": "96",
            "marks_12th": "89",
            "entrance_marks": "78",
            "pincode":"634500",
            "address": "321 MG Road",
            "city": "Noida",
            "state": "Delhi"
        },
        {
            "student_name": "Vinit Kumar",
            "mobile": "7778889999",
            "date_of_birth": "09-12-1996",
            "id_proof": "QWE987456",
            "selectedOperator": "Commerce",
            "gender": "Male",
            "marks_10th": "90",
            "marks_12th": "85",
            "entrance_marks": "75",
            "pincode":"444900",
            "address": "567 Mall Street",
            "city": "Dehradun",
            "state": "Uttarakhand"
        },
        {
            "student_name": "Madhura Senapati",
            "mobile": "33304445555",
            "date_of_birth": "07-25-1999",
            "id_proof": "WED444555",
            "selectedOperator": "Arts",
            "gender": "Female",
            "marks_10th": "85",
            "marks_12th": "80",
            "entrance_marks": "68",
            "pincode":"441200",
            "address": "876 MG Road",
            "city": "Kolkata",
            "state": "West Bengal"
        }

    ];


    // Initialize variables to store user input
    $scope.student_name = '';
    $scope.mobile = '';
    $scope.date_of_birth = '';
    $scope.id_proof = '';
    $scope.selectedOperator = '';
    $scope.gender = '';
    $scope.marks_10th = '';
    $scope.marks_12th = '';
    $scope.entrance_marks = '';
    $scope.pincode = '';
    $scope.address = '';
    $scope.city = '';
    $scope.state = '';

    $scope.isFormValid = true;
    // Function to handle form submission
    $scope.submitForm = function (inputString) {
        //Custom Services
        var inputString = $scope.student_name;

        if (inputString) {
            // Convert the inputString to proper case using the properCaseService
            $scope.student_name = properCaseService.processString(inputString);
        } else {
            $scope.student_name = '';
        }

        // Create an object with the submitted data
        var formDataObject = {
            student_name: $scope.student_name,
            mobile: $scope.mobile,
            date_of_birth: $scope.date_of_birth,
            id_proof: $scope.id_proof,
            selectedOperator: $scope.selectedOperator,
            gender: $scope.gender,
            marks_10th: $scope.marks_10th,
            marks_12th: $scope.marks_12th,
            entrance_marks: $scope.entrance_marks,
            pincode:$scope.pincode,
            address: $scope.address,
            city: $scope.city,
            state: $scope.state
        };

        // Push the object to the form array
        $scope.form.push(formDataObject);
        // Toggle visibility flags
        $scope.showDiv = true;
        $scope.submittedMessage = true;
    };

});